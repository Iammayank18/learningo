import { useEffect, useMemo, useState } from 'react'
import type { Exercise } from '../lib/quiz'
import { sfx } from '../lib/sound'
import { Mascot } from './Mascot'
import { t, type MessageKey } from '../lib/i18n'

const PRAISE: MessageKey[] = ['quiz.praise.correct', 'quiz.praise.exactly', 'quiz.praise.awesome', 'quiz.praise.spotOn', 'quiz.praise.wellDone', 'quiz.praise.niceOne']
const OOPS: MessageKey[] = ['quiz.oops.wrong', 'quiz.oops.noWorries', 'quiz.oops.almost']

interface Props { ex: Exercise; onNext: (correct: boolean) => void; combo?: number }

const shuffled = <T,>(a: T[]) => {
  const b = [...a]
  for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]] }
  return b
}

export function ExerciseView({ ex, onNext, combo = 0 }: Props) {
  if (ex.kind === 'mcq') return <Mcq ex={ex} onNext={onNext} combo={combo} />
  if (ex.kind === 'match') return <Match ex={ex} onNext={onNext} combo={combo} />
  return <Recall ex={ex} onNext={onNext} combo={combo} />
}

function Footer({ state, explain, onPrimary, primary, disabled, children, combo = 0 }: {
  state: 'idle' | 'ok' | 'bad'; combo?: number; explain?: string; onPrimary: () => void; primary: string; disabled?: boolean; children?: React.ReactNode
}) {
  const [line] = useState(() => ({ ok: PRAISE[Math.floor(Math.random() * PRAISE.length)], bad: OOPS[Math.floor(Math.random() * OOPS.length)] }))
  useEffect(() => {
    if (state === 'ok') sfx.correct(combo + 1)
    else if (state === 'bad') sfx.wrong()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state])
  return (
    <footer className={'qfooter ' + state}>
      <div className="qfooter-in">
        {state !== 'idle' && <Mascot mood={state === 'ok' ? 'happy' : 'sad'} size={52} />}
        <div className="qfeedback">
          {state === 'ok' && <strong>🎉 {combo >= 2 ? `${t('quiz.combo', { n: combo + 1 })} ${t(line.ok)}` : t(line.ok)}</strong>}
          {state === 'bad' && <strong>{t(line.bad)}</strong>}
          {state !== 'idle' && explain && <div className="qexplain">{explain}</div>}
          {children}
        </div>
        <button className={'btn ' + (state === 'bad' ? 'btn-red' : 'btn-green')} disabled={disabled} onClick={() => { sfx.tap(); onPrimary() }}>{primary}</button>
      </div>
    </footer>
  )
}

function Mcq({ ex, onNext, combo }: { ex: Extract<Exercise, { kind: 'mcq' }>; onNext: Props['onNext']; combo: number }) {
  const [sel, setSel] = useState<number | null>(null)
  const [checked, setChecked] = useState(false)
  const correct = sel === ex.answer

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return
      if (!checked && /^[1-9]$/.test(e.key) && +e.key <= ex.options.length) setSel(+e.key - 1)
      if (e.key === 'Enter') {
        e.preventDefault()
        if (checked) onNext(correct)
        else if (sel !== null) setChecked(true)
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [checked, sel, correct, ex.options.length, onNext])

  return (
    <>
      <div className="qbody">
        <div className="qtag">{ex.tag}</div>
        <h2 className="qprompt">{ex.prompt}</h2>
        {ex.sub && <blockquote className="qsub">{ex.sub}</blockquote>}
        <div className="opts">
          {ex.options.map((o, i) => {
            let cls = 'opt'
            if (sel === i) cls += ' sel'
            if (checked && i === ex.answer) cls += ' right'
            if (checked && sel === i && i !== ex.answer) cls += ' wrong'
            return (
              <button key={i} className={cls} disabled={checked} onClick={() => { sfx.select(); setSel(i) }}>
                <kbd>{i + 1}</kbd><span>{o}</span>
              </button>
            )
          })}
        </div>
      </div>
      {checked ? (
        <Footer combo={combo} state={correct ? 'ok' : 'bad'} explain={correct ? undefined : ex.explain} primary={t('common.continue')} onPrimary={() => onNext(correct)} />
      ) : (
        <Footer state="idle" primary={t('common.check')} disabled={sel === null} onPrimary={() => setChecked(true)} />
      )}
    </>
  )
}

function Match({ ex, onNext, combo }: { ex: Extract<Exercise, { kind: 'match' }>; onNext: Props['onNext']; combo: number }) {
  const lefts = useMemo(() => ex.pairs.map((p, i) => ({ t: p[0], i })), [ex])
  const rights = useMemo(() => shuffled(ex.pairs.map((p, i) => ({ t: p[1], i }))), [ex])
  const [left, setLeft] = useState<number | null>(null)
  const [done, setDone] = useState<Set<number>>(new Set())
  const [flash, setFlash] = useState<number | null>(null)
  const [mistakes, setMistakes] = useState(0)
  const finished = done.size === ex.pairs.length

  const pickRight = (i: number) => {
    if (left === null || done.has(i)) return
    if (left === i) {
      setDone(new Set(done).add(i)); setLeft(null); sfx.match()
    } else {
      setMistakes(mistakes + 1); setFlash(i); sfx.wrong()
      setTimeout(() => setFlash(null), 450)
    }
  }
  return (
    <>
      <div className="qbody">
        <div className="qtag">{ex.tag}</div>
        <h2 className="qprompt">{ex.prompt}</h2>
        <div className="match">
          <div className="match-col">
            {lefts.map((l) => (
              <button key={l.i} disabled={done.has(l.i)} className={'opt' + (left === l.i ? ' sel' : '') + (done.has(l.i) ? ' right' : '')} onClick={() => { sfx.select(); setLeft(l.i) }}>{l.t}</button>
            ))}
          </div>
          <div className="match-col">
            {rights.map((r) => (
              <button key={r.i} disabled={done.has(r.i)} className={'opt' + (done.has(r.i) ? ' right' : '') + (flash === r.i ? ' wrong' : '')} onClick={() => pickRight(r.i)}>{r.t}</button>
            ))}
          </div>
        </div>
      </div>
      {finished ? (
        <Footer combo={combo} state={mistakes === 0 ? 'ok' : 'bad'} explain={mistakes ? t('quiz.pairsWrong') : undefined} primary={t('common.continue')} onPrimary={() => onNext(mistakes === 0)} />
      ) : (
        <Footer state="idle" primary={t('quiz.matchFirst')} disabled onPrimary={() => {}} />
      )}
    </>
  )
}

function Recall({ ex, onNext, combo }: { ex: Extract<Exercise, { kind: 'recall' }>; onNext: Props['onNext']; combo: number }) {
  const [shown, setShown] = useState(false)
  return (
    <>
      <div className="qbody">
        <div className="qtag">{ex.tag} · {t('quiz.sayThenCheck')}</div>
        <h2 className="qprompt">{ex.prompt}</h2>
        {ex.sub && <p className="muted">{t('common.followUp')} {ex.sub}</p>}
        {shown ? (
          <div className="recall-answer"><div className="qtag">{t('common.referenceAnswer')}</div><p>{ex.answer}</p></div>
        ) : (
          <p className="muted">{t('quiz.recallHint')}</p>
        )}
      </div>
      <footer className="qfooter idle">
        <div className="qfooter-in">
          {shown ? (
            <div className="recall-btns">
              <button className="btn btn-red" onClick={() => { sfx.wrong(); onNext(false) }}>{t('quiz.needStudy')}</button>
              <button className="btn btn-green" onClick={() => { sfx.correct(combo + 1); onNext(true) }}>{t('quiz.remembered')}</button>
            </div>
          ) : (
            <button className="btn btn-blue" onClick={() => { sfx.tap(); setShown(true) }}>{t('quiz.showAnswer')}</button>
          )}
        </div>
      </footer>
    </>
  )
}
